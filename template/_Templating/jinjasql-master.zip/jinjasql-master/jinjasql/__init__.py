from jinjasql.core import JinjaSql 

__version__ = '0.1.7'
VERSION = tuple(map(int, __version__.split('.')))

__all__ = ['JinjaSql']
