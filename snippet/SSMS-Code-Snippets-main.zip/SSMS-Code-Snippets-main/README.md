# SSMS-Code-Snippets
Transact-SQL Code Snippets for SQL Server Management Studio
