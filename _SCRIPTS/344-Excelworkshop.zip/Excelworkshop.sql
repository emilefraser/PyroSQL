/*
The C.R.U.D. of Excel 

Phil and I have teamed up on this workbench, which demonstrates how to
create, read, update and delete information in Excel using T-SQL, from
SQL Server. As always, the workbench is structured so that it can be
pasted into Query Analyser and SSMS, and the individual examples
executed - so load it up and experiment!

We start by showing you how to create an Excel Spreadsheet from
SQL Server in TSQL(Transact SQL), create a worksheet, attach to it as 
a linked server, write to it, read from it, update it as if it was an 
ordinary SQL Server Database table, and then synchronise the data in 
the worksheet with SQL Server. We also illustrate the use of OPENQUERY,
OPENDATASOURCE and OPENROWSET.

To create the Excel spreadsheet, we show how to attach to an ADODB 
source from SQL Server and execute SQL against that source. We then 
show you an alternative 'quick cheat' way (using sp_makewebtask) to 
create and populate an excel spreadsheet from Transact SQL.

If you need more control over the Excel Spreadsheet that you are 
creating, we then show you how to do it via OLE automation. This will
enable you to do anything you can do via keystrokes, and allow you
to generate full Excel reports with pivot tables and Graphs.

Using this technique, you should be able to populate the data, or
place data in particular calls or ranges. You can even do 'macro
substitutions' 

A word of caution before you start. If you have your security wide
open, it is not just you who would be able to write out data as 
a spreadsheet. An intruder would be able to do it with that list 
of passwords or credit-card numbers. In a production system,
this sort of operation needs to be properly ring-fenced. We tend 
to create a job queue and have a special user, with the apporpriate
permissions, on the Task Scheduler, to do anything that involves
OLE automation or xp_CMDShell. Security precautions can get quite
complex, but they are outside the scope of the article.

Some of what we illustrate can be done using DTS or SSIS. 
Unfortunately, these are outside the scope of this article. In
fact, transferring data between Excel and SQL Server can be done
in a surprising variety of ways and it would be fun one day to
try to list them all. However, for now, let's get started'

First we need some simple test data
*/
Create table ##CambridgePubs 
		(Pubname varchar(40), 
		 Address varchar(80),
		 Postcode varchar(8))

insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Bees In The Wall','36 North Road,
 Whittlesford, Cambridge','CB2 4NZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Blackamoors Head','205 Victoria Road,
 Cambridge','CB4 3LF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Blue Lion','2 Horningsea Road,
 Fen Ditton, Cambridge','CB5 8SZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Cambridge Blue','85-87 Gwydir Street,
 Cambridge','CB1 2LG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Champion Of The Thames','68 King Street,
 Cambridge','CB1 1LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Cross Keys','77 Ermine Street,
 Caxton, Cambridge','CB3 8PQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Crown Inn','11 High Street,
 Linton, Cambridge','CB1 6HS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Devonshire Arms','1 Devonshire Road,
 Cambridge','CB1 2BH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Duke Of Argyle','90 Argyle Street,
 Cambridge','CB1 3LS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Duke Of Wellington','49 Alms Hill,
 Bourn, Cambridge','CB3 7SH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Eagle Public House','Benet Street,
 Cambridge','CB2 3QN'
/*And so on. (The full import file is in the ZIP, as is the Excel file!)
create the table and then execute the contents of CambridgePubs.SQL

Creating Excel spreadsheets via ADODB
-----------------------------------------

First, we need to create the spreadsheet with the correct headings
(PubName, Address, PostCode)

There are two possible ways one might do this. The most obvious way is 
to use the CREATE statement to create the worksheet and define the 
columns, but there seems to be no way of doing this by linking the 
excel FILE, unless the Excel file already exists. We need a utility 
stored procedure to get at ADODB in order to create databases and
execute DDL and SQL against it. */

create procedure spExecute_ADODB_SQL 
@DDL varchar(2000),
@DataSource Varchar(100),
@Worksheet varchar(100)=null,
@ConnectionString varchar(255) 
	=  'Provider=Microsoft.Jet.OLEDB.4.0;
		Data Source=%DataSource;
		Extended Properties=Excel 8.0'
as
Declare 
	@objExcel int,
	@hr int,
	@command varchar(255),
	@strErrorMessage varchar(255),
	@objErrorObject int,
	@objConnection int,
	@bucket int

Select @ConnectionString
	=replace (@ConnectionString, '%DataSource', @DataSource)
if @Worksheet is not null
	Select @DDL=replace(@DDL,'%worksheet',@Worksheet)

Select @strErrorMessage='Making ADODB connection ',
			@objErrorObject=null
EXEC @hr=sp_OACreate 'ADODB.Connection', @objconnection OUT
if @hr=0 Select @strErrorMessage='Assigning ConnectionString property "' 
			+ @ConnectionString + '"',
			@objErrorObject=@objconnection
if @hr=0 EXEC @hr=sp_OASetProperty @objconnection, 
			'ConnectionString', @ConnectionString
if @hr=0 Select @strErrorMessage
		='Opening Connection to XLS, for file Create or Append'
if @hr=0 EXEC @hr=sp_OAMethod @objconnection, 'Open'
if @hr=0 Select @strErrorMessage
		='Executing DDL "'+@DDL+'"'
if @hr=0 EXEC @hr=sp_OAMethod @objconnection, 'Execute',
		 @Bucket out , @DDL
if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	
	EXECUTE sp_OAGetErrorInfo  @objErrorObject, @source output,
		@Description output,@Helpfile output,@HelpID output
	Select @strErrorMessage='Error whilst '
		+coalesce(@strErrorMessage,'doing something')+', '
		+coalesce(@Description,'')
	raiserror (@strErrorMessage,16,1)
	end
EXEC @hr=sp_OADestroy @objconnection
go
--------------------------------------
/* Now we have it, it is easy */

spExecute_ADODB_SQL @DDL='Create table CambridgePubs
(Pubname Text, Address Text, Postcode Text)',
@DataSource ='C:\CambridgePubs.xls'
--this excel file will have been created on the Database server of the
-- database you currently have a connection to

--We could now insert data into the spreadsheet, if we wanted
spExecute_ADODB_SQL @DDL='insert into CambridgePubs 
	(Pubname,Address,Postcode)
	values (''The Bird in Hand'',
			''23, Marshall Road, Cambridge CB4 2DQ'',
			''CB4 2DQ'')',
@DataSource ='C:\CambridgePubs.xls'

--you could drop it again!
spExecute_ADODB_SQL @DDL='drop table CambridgePubs',
@DataSource ='c:\CambridgePubs.xls'

/* Manipulating Excel data via a linked server
----------------------------------------------

We can now link to the created excel file as follows */

EXEC sp_addlinkedserver 'CambridgePubDatabase', 
@srvproduct = '', 
@provider = 'Microsoft.Jet.OLEDB.4.0', 
@datasrc = 'C:\CambridgePubs.xls', 
@provstr = 'Excel 8.0;'
GO

EXEC sp_addlinkedsrvlogin 'CambridgePubDatabase', 'false'
GO

--to drop the link, we do this!
--EXEC sp_dropserver 'CambridgePubDatabase', 'droplogins'

-- Get the spreadsheet data via OpenQuery
SELECT * FROM OPENQUERY
	(CambridgePubDatabase, 'select * from [CambridgePubs]')
GO
--or more simply, do this 
Select * from CambridgePubDatabase...CambridgePubs

--so now we can insert our data into the Excel Spreadsheet
insert into CambridgePubDatabase...CambridgePubs 
	(Pubname, Address, postcode)
	select Pubname, Address, postcode from ##CambridgePubs

/*Synchronizing the Spreadsheet with SQL Server tables
------------------------------------------------------

As we are directly manipulating the Excel data in the worksheet as if
it was a table we can do joins. 

What about synchronising the table after editing the excel spreadsheet?

To try this out, you'll need to delete, alter and insert a few rows 
from the excel spreadsheet, remembering to close it after you've done it */


--Firstly, we'll delete any rows from ##CambridgePubs
-- that do not exist in the Excel spreadsheet

Delete from ##CambridgePubs 
from  ##CambridgePubs c 
left outer join CambridgePubDatabase...CambridgePubs ex 
on c.address like ex.address 
	and c.pubname like ex.pubname 
	and c.postcode like ex.postcode
where ex.pubname is NULL

-- then we insert into #CambridgePubs any rows in the spreadsheet
-- that don't exist in #CambridgePubs

insert into ##CambridgePubs (Pubname,Address,Postcode)
select ex.Pubname,ex.Address,ex.Postcode
from  CambridgePubDatabase...CambridgePubs ex 
left outer join ##CambridgePubs c 
on c.address like ex.address 
	and c.pubname like ex.pubname 
	and c.postcode like ex.postcode
where c.pubname is null

--all done (reverse syncronisation would be similar)

/*Manipulating Excel data using OPENDATASOURCE and OPENROWSET
-------------------------------------------------------------

If you don't want to do the linking, you can also read the data like
 this*/

SELECT * 
FROM OpenDataSource( 'Microsoft.Jet.OLEDB.4.0',
  'Data Source="C:\CambridgePubs.xls";
    Extended properties=Excel 8.0')...CambridgePubs
--and write to it

UPDATE OPENDATASOURCE ('Microsoft.Jet.OleDB.4.0', 
 'Data Source="C:\CambridgePubs.xls";
 extended Properties=Excel 8.0')...CambridgePubs
set Address='St. Kilda Road, Cambridge' 
where Pubname = 'Jenny Wren'

INSERT INTO OPENDATASOURCE ('Microsoft.Jet.OleDB.4.0', 
 'Data Source="C:\CambridgePubs.xls";
 extended Properties=Excel 8.0')...CambridgePubs
(Pubname,Address,Postcode )
Select 'The St George','65 Cavendish Road','CB2 4RT'

--You can read and write toExcel Sheet using OpenRowSet, 
--if the mood takes you

select * FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;DATABASE=C:\CambridgePubs.xls', 'Select * from CambridgePubs')

UPDATE  OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;DATABASE=c:\CambridgePubs.xls',
 'Select * from CambridgePubs')
       set Address='34 Glemsford Road' where Address = '65 Cavendish Road'

INSERT INTO OPENROWSET ('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;DATABASE=c:\CambridgePubs.xls',
 'Select * from CambridgePubs')
(Pubname, Address, Postcode)
Select 'The Bull', 'Antioch Road','CB2 5TY'

/*Creating Excel Spreadsheets using sp_makewebtask
--------------------------------------------------

Instead of creating the Excel spreadsheet with OLEDB One can use the 
sp_makewebtask

Users must have SELECT permissions to run a specified query and 
CREATE PROCEDURE permissions in the database in which the query will run. 
The SQL Server account must have permissions to write the generated HTML
document to the specified location. Only members of the sysadmin server role
can impersonate other users. 
*/

sp_makewebtask @outputfile = 'c:\CambridgePubsHTML2.xls', 
    @query = 'Select * from ##CambridgePubs',
    @colheaders =1, 
	@FixedFont=0,@lastupdated=0,@resultstitle='Cambridge Pubs',
    @dbname ='MyDatabaseName'

/* This is fine for distributing information from databases but no good
if you subsequently want to open it via ODBC.*/

/*OLE Automation
----------------

So far, so good. However, we really want rather more than this. When
we create an excel file for a business report, we want the data and we 
also want nice formatting, defined ranges, sums, calculated fields
and pretty graphs. If we do financial reporting, we want a pivot table
and so on in order to allow a degree of data mining by the recipient.
A different approach is required.

We can, of course, use Excel to extract the data from the database. 
However, in this example, we'll create a spreadsheet, write the data 
into it, fit the columns nicely and define a range around the data

*/

CREATE procedure [dbo].[spDMOExportToExcel] (
@SourceServer varchar(30),
@SourceUID varchar(30)=null,
@SourcePWD varchar(30)=null,
@QueryText varchar(200),
@filename varchar(100),
@WorksheetName Varchar(100)='Worksheet',
@RangeName Varchar(80)='MyRangeName'
)
AS
DECLARE @objServer int,
@objQueryResults int,
@objCurrentResultSet int,
@objExcel int,
@objWorkBooks int,
@objWorkBook int,
@objWorkSheet int,
@objRange int,
@hr int,
@Columns int,
@Rows int,
@Output int,
@currentColumn int,
@currentRow int,
@ResultSetRow int,
@off_Column int,
@off_Row int,
@command varchar(255),
@ColumnName varchar(255),
@value varchar(255),
@strErrorMessage varchar(255),
@objErrorObject int,
@Alphabet varchar(27)

Select @Alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ'

IF @QueryText IS NULL 
	BEGIN
	raiserror ('A query string is required for spDMOExportToExcel',16,1)
	RETURN 1
	END

-- Sets the server to the local server
IF @SourceServer IS NULL SELECT @SourceServer = @@servername

SET NOCOUNT ON

SELECT @strErrorMessage = 'instantiating the DMO',
	@objErrorObject=@objServer
exec @hr= sp_OACreate 'SQLDMO.SQLServer', @objServer OUT

if @SourcePWD is null or @SourceUID is null
	begin
	--use a trusted connection 
	if @hr=0 Select @strErrorMessage=
	'Setting login to windows authentication on '
	+@SourceServer, @objErrorObject=@objServer
	if @hr=0 exec @hr=sp_OASetProperty @objServer, 'LoginSecure', 1
	if @hr=0 Select @strErrorMessage=
	'logging in to the requested server using windows authentication on '
		+@SourceServer
	if @SourceUID is null and @hr=0 exec @hr=sp_OAMethod @objServer,
		'Connect', NULL, @SourceServer 
	if @SourceUID is not null and @hr=0 
		exec @hr=sp_OAMethod 
			@objServer, 'Connect', NULL, @SourceServer ,@SourceUID
	end
else
	Begin
	if @hr=0 SELECT @strErrorMessage = 'Connecting to '''+@SourceServer+
		''' with user ID '''+@SourceUID+'''', @objErrorObject=@objServer
	if @hr=0 
		exec @hr=sp_OAMethod @objServer, 'Connect', NULL, 
			@SourceServer, @SourceUID, @SourcePWD
	end

--now we execute the query
if @hr=0 Select @strErrorMessage='executing the query "'
		+@querytext+'", on '+@SourceServer, 
		@objErrorObject=@objServer, 
		@command = 'ExecuteWithResults("' + @QueryText + '")'
if @hr=0 
	EXEC @hr=sp_OAMethod @objServer, @command, @objQueryResults OUT

if @hr=0 Select @strErrorMessage='getting the first result set for "'
		+@querytext+'", on '+@SourceServer, 
		@objErrorObject=@objQueryResults
if @hr=0 EXEC @hr=sp_OAMethod 
	@objQueryResults, 'CurrentResultSet', @objCurrentResultSet OUT
if @hr=0 
	Select @strErrorMessage='getting the rows and columns "'
		+@querytext+'", on '+@SourceServer 
if @hr=0 
	EXEC @hr=sp_OAMethod @objQueryResults, 'Columns', @Columns OUT
if @hr=0 
	EXEC @hr=sp_OAMethod @objQueryResults, 'Rows', @Rows OUT

--so now we have the queryresults. We start up Excel
if @hr=0 
	Select @strErrorMessage='Creating the Excel Application, on '
		+@SourceServer, @objErrorObject=@objExcel
if @hr=0 
	EXEC @hr=sp_OACreate 'Excel.Application', @objExcel OUT
if @hr=0 Select @strErrorMessage='Getting the WorkBooks object '
if @hr=0 
	EXEC @hr=sp_OAGetProperty @objExcel, 'WorkBooks',
		@objWorkBooks OUT
--create a workbook		
if @hr=0 
	Select @strErrorMessage='Adding a workbook ',
		@objErrorObject=@objWorkBooks
if @hr=0 
	EXEC @hr=sp_OAGetProperty @objWorkBooks, 'Add', @objWorkBook OUT

--and a worksheet
if @hr=0 
	Select @strErrorMessage='Adding a worksheet ',
		@objErrorObject=@objWorkBook
if @hr=0 
	EXEC @hr=sp_OAGetProperty @objWorkBook, 'worksheets.Add', 
		@objWorkSheet OUT

if @hr=0 
	Select @strErrorMessage='Naming a worksheet as "'
		+@WorksheetName+'"', @objErrorObject=@objWorkBook
if @hr=0  
	EXEC @hr=sp_OASetProperty @objWorkSheet, 'name', @WorksheetName

SELECT @currentRow = 1

--so let's write out the column headings
SELECT @currentColumn = 1
WHILE (@currentColumn <= @Columns and @hr=0)
		begin
		if @hr=0 
			Select @strErrorMessage='getting column heading '
									+LTRIM(str(@currentcolumn)) ,
				@objErrorObject=@objQueryResults,
				@Command='ColumnName('
							+convert(varchar(3),@currentColumn)+')'
		if @hr=0 EXEC @hr=sp_OAGetProperty @objQueryResults, 
											@command, @ColumnName OUT
		if @hr=0 Select @strErrorMessage='assigning the column heading '+
			+ LTRIM(str(@currentColumn))
			+ ' from the query string',
			@objErrorObject=@objExcel,
			@command='Cells('+ltrim(str(@currentRow)) +', '
								+ ltrim(str(@CurrentColumn))+').value'
		if @hr=0 
			EXEC @hr=sp_OASetProperty @objExcel, @command, @ColumnName
		SELECT @currentColumn = @currentColumn + 1
		end

--format the headings in Bold nicely
if @hr=0 
	Select @strErrorMessage='formatting the column headings in bold ',
		@objErrorObject=@objWorkSheet,
		@command='Range("A1:'+substring(@alphabet,@currentColumn / 26,1)+
			substring(@alphabet,@currentColumn % 26,1)+'1'+'").font.bold'
if @hr=0 EXEC @hr=sp_OASetProperty @objWorkSheet, @command, 1
--now we write out the data

SELECT @currentRow = 2
WHILE (@currentRow <= @Rows+1 and @hr=0)
	BEGIN
	SELECT @currentColumn = 1
	WHILE (@currentColumn <= @Columns and @hr=0)
		BEGIN
		if @hr=0 
			Select 
			@strErrorMessage=
				'getting the value from the query string' 
				+ LTRIM(str(@currentRow)) +',' 
				+ LTRIM(str(@currentRow))+')',
			@objErrorObject=@objQueryResults, 
			@ResultSetRow=@CurrentRow-1
		if @hr=0 
			EXEC @hr=sp_OAMethod @objQueryResults, 'GetColumnString', 
				@value OUT, @ResultSetRow, @currentColumn
		if @hr=0 
			Select @strErrorMessage=
					'assigning the value from the query string' 
				+ LTRIM(str(@CurrentRow-1)) +', ' 
				+ LTRIM(str(@currentcolumn))+')' ,
				@objErrorObject=@objExcel,
				@command='Cells('+str(@currentRow) +', '
										+ str(@CurrentColumn)+').value'
		if @hr=0 EXEC @hr=sp_OASetProperty @objExcel, @command, @value
		SELECT @currentColumn = @currentColumn + 1
		END
	SELECT @currentRow = @currentRow + 1
	END
--define the name range
--Cells(1, 1).Resize(10, 5).Name = "TheData"
if @hr=0 Select @strErrorMessage='assigning a name to a range ' 
		+ LTRIM(str(@CurrentRow-1)) +', ' 
		+ LTRIM(str(@currentcolumn-1))+')' ,
	@objErrorObject=@objExcel,
	@command='Cells(1, 1).Resize('+str(@currentRow-1) +', '
									+ str(@CurrentColumn-1)+').Name'
if @hr=0 EXEC @hr=sp_OASetProperty @objExcel, @command, @RangeName

--Now autofilt the columns we've written to
if @hr=0 Select @strErrorMessage='Auto-fit the columns ',
			@objErrorObject=@objWorkSheet,
			@command='Columns("A:'+substring(@alphabet,(@Columns / 26),1)+
				substring(@alphabet,(@Columns % 26),1)+
				'").autofit'

if @hr=0 --insert into @bucket(bucket)
		EXEC @hr=sp_OAMethod  @objWorkSheet, @command, @output out


if @hr=0 SELECT @command ='del "' + @filename + '"'
if @hr=0 execute master..xp_cmdshell @Command, no_output
if @hr=0 
	Select @strErrorMessage='Saving the workbook as "' + @filename + '"',
		@objErrorObject=@objRange, 
		@command = 'SaveAs("' + @filename + '")'
if @hr=0 EXEC @hr=sp_OAMethod @objWorkBook, @command
if @hr=0 Select @strErrorMessage='closing Excel ',
		@objErrorObject=@objExcel
EXEC @hr=sp_OAMethod @objWorkBook, 'Close'
EXEC sp_OAMethod @objExcel, 'Close'

if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	
	EXECUTE sp_OAGetErrorInfo  @objErrorObject, 
		@source output,@Description output,@Helpfile output,@HelpID output
	select @hr, @source, @Description,@Helpfile,@HelpID output
	Select @strErrorMessage='Error whilst '
			+coalesce(@strErrorMessage,'doing something')
			+', '+coalesce(@Description,'')
	raiserror (@strErrorMessage,16,1)
	end
EXEC sp_OADestroy @objServer
EXEC sp_OADestroy @objQueryResults
EXEC sp_OADestroy @objCurrentResultSet
EXEC sp_OADestroy @objExcel
EXEC sp_OADestroy @objWorkBooks
EXEC sp_OADestroy @objWorkBook
EXEC sp_OADestroy @objRange
return @hr
GO

--Now we can create our pubs spreadsheet, and can do it from any of
--our servers
--
spDMOExportToExcel @SourceServer='MyServer',
@SourceUID= 'MyUserID',
@SourcePWD = 'MyPassword',
@QueryText = 'use MyDatabase 
	select Pubname, Address, Postcode from ##CambridgePubs',
@filename = 'MyPubDatabase.xls',
@WorksheetName='MyFavouritePubs',
@RangeName ='MyRangeName'

--or if you are using integrated security!
spDMOExportToExcel @SourceServer='MyServer',
@QueryText = 'use MyDatabase 
	select Pubname, Address, Postcode from ##CambridgePubs',
@filename = 'C:\MyPubDatabase.xls',
@WorksheetName='MyFavouritePubs',
@RangeName ='MyRangeName'


/* Although this is a very handy stored procedure, you'll probably need
to modify and add to it for particular purposes.

We use the DMO method because we like to dump build data into Excel
spreadsheets e.g. users, logins, Job Histories. However, an ADODB
version is very simple to do and can be made much faster for reads and
writes.

We have just inserted values, but you can insert formulae and formatting 
(numberformat) and create or change borders. You can, in fact, manipulate the
spreadsheet in any way you like. When we do this, we record macros in Excel
and then convert these macros to TSQL! Using the above example, it should 
be simple*/




