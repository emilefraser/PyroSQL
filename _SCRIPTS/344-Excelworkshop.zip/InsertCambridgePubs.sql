insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Bees In The Wall','36 North Road,
 Whittlesford, Cambridge','CB2 4NZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Blackamoors Head','205 Victoria Road,
 Cambridge','CB4 3LF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Blue Lion','2 Horningsea Road,
 Fen Ditton, Cambridge','CB5 8SZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Cambridge Blue','85-87 Gwydir Street,
 Cambridge','CB1 2LG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Champion Of The Thames','68 King Street,
 Cambridge','CB1 1LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Cross Keys','77 Ermine Street,
 Caxton, Cambridge','CB3 8PQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Crown Inn','11 High Street,
 Linton, Cambridge','CB1 6HS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Devonshire Arms','1 Devonshire Road,
 Cambridge','CB1 2BH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Duke Of Argyle','90 Argyle Street,
 Cambridge','CB1 3LS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Duke Of Wellington','49 Alms Hill,
 Bourn, Cambridge','CB3 7SH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Eagle Public House','Benet Street,
 Cambridge','CB2 3QN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'George & Dragon (Elsworth) Ltd','41 Boxworth Road,
 Elsworth, Cambridge','CB3 8JQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Granta','14 Newnham Terrace,
 Cambridge','CB3 9EX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Green Dragon','5 Water Street,
 Cambridge','CB4 1NZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Ha Ha Bar & Canteen','17 Trinity Street,
 Cambridge','CB2 1TB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Hogs Head','69-73 Regent Street,
 Cambridge','CB2 1AB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Hunters Fen','Twentypence Road,
 Cottenham, Cambridge','CB4 8SP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Jenny Wren','St. Kilda Avenue,
 Cambridge','CB4 2QA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'King William IV','9 Church Street,
 Histon, Cambridge','CB4 9EP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Kings Head','19 High Street,
 Sawston, Cambridge','CB2 4BG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Kisbys Hut','Ermine Street North,
 Papworth Everard, Cambridge','CB3 8RJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Live & Let Live','40 Mawson Road,
 Cambridge','CB1 2EA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Montfort Arms Ltd','Haverhill Road,
 Horseheath, Cambridge','CB1 6QR'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Prince Regent','91 Regent Street,
 Cambridge','CB2 1AW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Po Na Na','7a Jesus Lane,
 Cambridge','CB5 8BA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Plough Public House','High Street,
 Great Shelford, Cambridge','CB2 5EH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Plough & Fleece','High Street,
 Horningsea, Cambridge','CB5 9JG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Pike & Eel','110 Water Street,
 Cambridge','CB4 1PA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Pickerel Inn','30 Magdalene Street,
 Cambridge','CB3 0AF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Panton Arms','43 Panton Street,
 Cambridge','CB2 1HL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Quay Bar','3-5 Quayside,
 Cambridge','CB5 8AB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Queens Head','90 High Street,
 Sawston, Cambridge','CB2 4HJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Railway Tavern','Station Road,
 Great Shelford, Cambridge','CB2 5LR'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Rat & Parrot','Thompsons Lane,
 Cambridge','CB5 8AQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Rat & Parrott','7-8 Downing Street,
 Cambridge','CB2 3DS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Red Lion','Cherryinton,
 Mill End Road, Cambridge','CB1 9JP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Red Lion','43 High Street,
 Swaffham Prior, Cambridge','CB5 0LD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Rose & Crown','1 High Street,
 Teversham, Cambridge','CB1 5AF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'St Radegund','127 King Street,
 Cambridge','CB1 1LD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Sir Isaac Newton','84 Castle Street,
 Cambridge','CB3 0AJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Snowcat','Arbury Court,
 Arbury Road, Cambridge','CB4 2JJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Trinity Foot','Huntingdon Road,
 Swavesey, Cambridge','CB4 5RD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Admiral Vernon','31 High Street,
 Over, Cambridge','CB4 5NB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Alexandra Arms','22-24 Gwydir Street,
 Cambridge','CB1 2LL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Alma','26 Russell Court,
 Cambridge','CB2 1HW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Anchor','Silver Street,
 Cambridge','CB3 9EL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bakers Arms','4 Hinton Road,
 Fulbourn, Cambridge','CB1 5DZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bakers Yard','176 East Road,
 Cambridge','CB1 1BG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Barley Mow','7 High Street,
 Histon, Cambridge','CB4 9JD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Baron Of Beef','19 Bridge Street,
 Cambridge','CB2 1UF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bath House','3 Benet Street,
 Cambridge','CB2 3QN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bell','2 West Wickham Road,
 Balsham, Cambridge','CB1 6DZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bell','16 High Street,
 Bottisham, Cambridge','CB5 9DA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Black Bull','98 High Street,
 Sawston, Cambridge','CB2 4HJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Black Bull','1 Station Road,
 Willingham, Cambridge','CB4 5HF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Black Horse','Park Street,
 Dry Drayton, Cambridge','CB3 8DA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Black Horse','6 High Street,
 Rampton, Cambridge','CB4 8QE'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Black Horse','35 High Street,
 Swaffham Bulbeck, Cambridge','CB5 0HP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Blue Ball Inn','57 Broadway,
 Grantchester, Cambridge','CB3 9NQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Blue Lion','74 Main Street,
 Hardwick, Cambridge','CB3 7QU'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Boat House','14 Chesterton Road,
 Cambridge','CB4 3AX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Boat Race','170 East Road,
 Cambridge','CB1 1DB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Boot Inn','1 High Street,
 Histon, Cambridge','CB4 9LG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Brewery Tap','19 Denny End Road,
 Waterbeach, Cambridge','CB5 9PB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The British Queen','100 Histon Road,
 Cambridge','CB4 3JP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Brook','25 Brookfields,
 Cambridge','CB1 3NW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Bun Shop','1 King Street,
 Cambridge','CB1 1LH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Burleigh Arms','9-11 Newmarket Road,
 Cambridge','CB5 8EG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Cambridge Rattle & Hum','Cambridge Arms,
 4 King Street, Cambridge','CB1 1LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Carlton Arms','Carlton Way,
 Cambridge','CB4 2BY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Carpenters Arms','10 High Street,
 Great Wilbraham, Cambridge','CB1 5JD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Carpenters Arms','182-186 Victoria Road,
 Cambridge','CB4 3DZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Castle','37 St Andrews Street,
 Cambridge','CB2 3AZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Castle Inn','36 Castle Street,
 Cambridge','CB3 0AJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Chequers','297 High Street,
 Cottenham, Cambridge','CB4 8QP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Chequers Inn','1 Town Lane,
 Pampisford, Cambridge','CB2 4ER'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Clarendon Arms','35 Clarendon Street,
 Cambridge','CB1 1JX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Coach & Horses','High Street,
 Trumpington, Cambridge','CB2 2LP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Cock','High Street,
 Castle Camps, Cambridge','CB1 6SN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Corner House','231 Newmarket Road,
 Cambridge','CB5 8JE'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The County Arms','43 Castle Street,
 Cambridge','CB3 0AH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Cricketers','18 Melbourne Place,
 Cambridge','CB1 1EQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Cross Keys','Saxon Street,
 Cambridge','CB2 1HN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Crown','88 High Street,
 Burwell, Cambridge','CB5 0HD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Dobblers Inn','184 Sturton Street,
 Cambridge','CB1 2QF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Dog & Duck','63 High Street,
 Linton, Cambridge','CB1 6HS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Durham Ox','83 Mill Road,
 Cambridge','CB1 2AW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Dykes End','8 Fair Green,
 Reach, Cambridge','CB5 0JD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Earl Of Beaconsfield','133 Mill Road,
 Cambridge','CB1 3AA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Elm Tree','Orchard Street,
 Cambridge','CB1 1JT'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Empress','72 Thoday Street,
 Cambridge','CB1 3AX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Exhibition','2 King Street,
 Over, Cambridge','CB4 5PS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Five Bells','143-145 High Street,
 Cherry Hinton, Cambridge','CB1 9LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Five Bells','44 High Street,
 Burwell, Cambridge','CB5 0HD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Five Bells','126 Newmarket Road,
 Cambridge','CB5 8HE'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Fleur De Lys','73 Humberstone Road,
 Cambridge','CB4 1JD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Fort Saint George','Midsummer Common,
 Cambridge','CB4 1HA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Fountain Inn','12 Regent Street,
 Cambridge','CB2 1DB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Fox','The Mall,
 Bar Hill, Cambridge','CB3 8DZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Fox Inn','2 North Street,
 Burwell, Cambridge','CB5 0BA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Free Press','7 Prospect Row,
 Cambridge','CB1 1DU'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Geldart','1 Ainsworth Street,
 Cambridge','CB1 2PF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The George','71 High Street,
 Girton, Cambridge','CB3 0QD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The George Inn','High Street,
 Babraham, Cambridge','CB2 4AG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The George Inn','71 High Street,
 Girton, Cambridge','CB3 0QD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Globe','21 Hills Road,
 Cambridge','CB2 1NW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Golden Ball','High Street,
 Boxworth, Cambridge','CB3 8LY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Golden Hind','355 Milton Road,
 Cambridge','CB4 1SP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Golden Lion','High Street,
 Bourn, Cambridge','CB3 7SQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Golden Pheasant','169 High Street,
 Chesterton, Cambridge','CB4 1NL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Graduate','16 Chesterton Road,
 Cambridge','CB4 3AX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Grapes','19 Histon Road,
 Cambridge','CB4 3JB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Grapevine','5 Green End,
 Comberton, Cambridge','CB3 7DY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Grasshopper','2 Brookfields,
 Mill Road, Cambridge','CB1 3NW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Green Man','59 High Street,
 Grantchester, Cambridge','CB3 9NF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Greyhound','93 Coldhams Lane,
 Cambridge','CB1 3EN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Hare & Hounds','60 High Street,
 Harlton, Cambridge','CB3 7ES'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Hat & Feathers','35 Barton Road,
 Cambridge','CB3 9LB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Haymakers','54 High Street,
 Chesterton, Cambridge','CB4 1NG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Hoops','School Lane,
 Barton, Cambridge','CB3 7BD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Hop Bind','212 High Street,
 Cottenham, Cambridge','CB4 8RZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Hopbine','Fair Street,
 Cambridge','CB1 1HA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The John Barleycorn','Moorfield Road,
 Duxford, Cambridge','CB2 4PP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Jolly Brewers','Fen Road,
 Milton, Cambridge','CB4 6AD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Jolly Millers','73 High Street,
 Cottenham, Cambridge','CB4 8SD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Jolly Waterman','32 Chesterton Road,
 Cambridge','CB4 3AX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Jubilee','73 Catharine Street,
 Cambridge','CB1 3AP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The King Street Run','86 King Street,
 Cambridge','CB1 1LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Kings Head','Hadstock, Cambridge','CB1 6NX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Kings Head','50 High Street,
 Fen Ditton, Cambridge','CB5 8ST'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Kingston Arms','33 Kingston Street,
 Cambridge','CB1 2NU'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Lion & Lamb','High Street,
 Milton, Cambridge','CB4 6DF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Little Rose','7 Orchard Road,
 Haslingfield, Cambridge','CB3 7JT'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Locomotive','44 Mill Road,
 Cambridge','CB1 2AS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Longbow Public House','2 Church Street,
 Stapleford, Cambridge','CB2 5DS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Master Mariner','Perne Road,
 Cambridge','CB1 3RX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Maypole','Park Street,
 Cambridge','CB5 8AS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Mill','14 Mill Lane,
 Cambridge','CB2 1RX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Milton Arms','205 Milton Road,
 Cambridge','CB4 1XG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Mitre Tavern','17 Bridge Street,
 Cambridge','CB2 1UF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Navigator','63 High Street,
 Little Shelford, Cambridge','CB2 5ES'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Old Crown Inn','89 High Street,
 Girton, Cambridge','CB3 0QD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Old English Gentleman','180 High Street,
 Harston, Cambridge','CB2 5QD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Old Red Lion','Linton Road,
 Horseheath, Cambridge','CB1 6QF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Old Spring','1 Ferry Path,
 Cambridge','CB4 1HB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Osborne Arms','108 Hills Road,
 Cambridge','CB2 1LQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Pear Tree','Hildersham, Cambridge','CB1 6BU'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Pemberton Arms','2 High Street,
 Harston, Cambridge','CB2 5PX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Plough','59 St Peters Street,
 Duxford, Cambridge','CB2 4RP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Plough','High Street,
 Coton, Cambridge','CB3 7PL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Poacher','1 Brockley Road,
 Elsworth, Cambridge','CB3 8JS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Portland Arms','129 Chesterton Road,
 Cambridge','CB4 3BA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Queen Edith','Queen Edith,
 Wulfstan Way, Cambridge','CB1 8QN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Queens Head','48 Royston Road,
 Harston, Cambridge','CB2 5NH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Queens Head','Fowlmere Road,
 Newton, Cambridge','CB2 5PG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Railway Vue','163 Station Road,
 Impington, Cambridge','CB4 9NP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Red Bull','11 Barton Road,
 Cambridge','CB3 9JY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Red Bull','11 Barton Road,
 Cambridge','CB3 9JZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Red Cow','Corn Exchange Street,
 Cambridge','CB2 3QF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Red Lion','33 High Street,
 Grantchester, Cambridge','CB3 9NF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Red Lion','27 High Street,
 Histon, Cambridge','CB4 9JD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Regal','38-39 St. Andrews Street,
 Cambridge','CB2 3AR'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Robin Hood & Little John','1 Fulbourn Road,
 Cambridge','CB1 9JL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Rock','200 Cherry Hinton Road,
 Cambridge','CB1 7AW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Rose','81 London Road,
 Stapleford, Cambridge','CB2 5DG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Rose & Crown','2 Glebe Way,
 Impington, Cambridge','CB4 9JB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Rosemary Branch','503 Coldhams Lane,
 Cambridge','CB1 3JH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Royal Oak','Barrington, Cambridge','CB2 5RZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Royal Standard','292 Mill Road,
 Cambridge','CB1 3NL'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Rupert Brooke','2 Broadway,
 Grantchester, Cambridge','CB3 9NQ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Salisbury Arms','76 Tenison Road,
 Cambridge','CB1 2DW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Seven Stars','249 Newmarket Road,
 Cambridge','CB5 8JE'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Ship','Northfields Avenue,
 Cambridge','CB4 2LG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Six Bells','11 Covent Garden,
 Cambridge','CB1 2HS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Six Bells','9 High Street,
 Fulbourn, Cambridge','CB1 5DH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Spread Eagle','67 Lensfield Road,
 Cambridge','CB2 1EN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Square & Compasses','46 High Street,
 Great Shelford, Cambridge','CB2 5EH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Sun Inn','7 Chapel Street,
 Waterbeach, Cambridge','CB5 9HR'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Tally-Ho','77 High Street,
 Trumpington, Cambridge','CB2 2HZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Tap & Spile','14 Mill Lane,
 Cambridge','CB2 1RX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Three Hills','Bartlow, Cambridge','CB1 6PW'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Three Horseshoes','21 High Street,
 Harston, Cambridge','CB2 5PX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Three Tuns','75 High Street,
 Great Abington, Cambridge','CB1 6AB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Three Tuns','43 Church Street,
 Willingham, Cambridge','CB4 5HS'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Tram Depot','5 Dover Street,
 Cambridge','CB1 1DY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Travellers Rest','Ely Road,
 Chittering, Cambridge','CB5 9PH'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Tree','9 Bar Lane,
 Stapleford, Cambridge','CB2 5BJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Unicorn','15 High Street,
 Cherry Hinton, Cambridge','CB1 9HX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Unicorn','22 Church Lane,
 Cambridge','CB2 2LA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Volunteer','Trumpington Road,
 Cambridge','CB2 2EX'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Waggon & Horses','39 High Street,
 Milton, Cambridge','CB4 6DF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wagon & Horses','110 High Street,
 Linton, Cambridge','CB1 6JT'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wagon & Horses','69 Margett Street,
 Cottenham, Cambridge','CB4 8QY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wheatsheaf','4 St. Peters Street,
 Duxford, Cambridge','CB2 4RP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wheatsheaf','Cambridge Road,
 Harlton, Cambridge','CB3 7HA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wheatsheaf','114 Stow Road,
 Stow-cum-Quy, Cambridge','CB5 9AD'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Hart','Sturton Street,
 Cambridge','CB1 2QA'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','3 High Street,
 West Wickham, Cambridge','CB1 6RY'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','London Road,
 Pampisford, Cambridge','CB2 4EF'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','45 High Street,
 Foxton, Cambridge','CB2 6RP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','118 High Street,
 Barton, Cambridge','CB3 7BG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','28 Longstanton Road,
 Oakington, Cambridge','CB4 5AB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','High Street,
 Milton, Cambridge','CB4 6AJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse','12 Greenside,
 Waterbeach, Cambridge','CB5 9HP'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Horse Inn','1 Market Street,
 Swavesey, Cambridge','CB4 5QG'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Swan','109 Mill Road,
 Cambridge','CB1 2AZ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Swan','Elsworth Road,
 Conington, Cambridge','CB3 8LN'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The White Swan','Main Street,
 Stow-cum-Quy, Cambridge','CB5 9AB'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Woolpack','70 High Street,
 Sawston, Cambridge','CB2 4HJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'The Wrestlers','337 Newmarket Road,
 Cambridge','CB5 8JE'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'Three Tuns','High Street,
 Fen Drayton, Cambridge','CB4 5SJ'
insert into ##CambridgePubs (PubName, Address, Postcode)
	select 'White Hart','1 Balsham Road,
 Fulbourn, Cambridge','CB1 5BZ'
