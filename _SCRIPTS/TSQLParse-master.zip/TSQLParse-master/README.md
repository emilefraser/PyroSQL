# TSQLParse
Simple TSQL Parser creator using t4 template
