﻿namespace sdmap.ext
{
    public interface ISdmapEmiter
    {
        string Emit(string statementId, object parameters);
    }
}
