﻿namespace sdmap.Macros
{
    public enum SdmapTypes
    {
        Syntax, 
        Date, 
        Number, 
        String, 
        Sql, 
        StringOrSql, 
        Bool, 
        Any, 
    }
}
