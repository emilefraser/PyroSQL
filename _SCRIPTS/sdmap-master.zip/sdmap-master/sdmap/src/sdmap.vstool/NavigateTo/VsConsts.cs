﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sdmap.Vstool.NavigateTo
{
    public static class VsConsts
    {
        public const string CSharpLanguage = "{B5E9BD34-6D3E-4B5D-925E-8A43B79820B4}";

        public const string CSharpProject = "{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}";

        public const string CSharpCoreProject = "{9A19103F-16F7-4668-BE54-9A1E7A4F7556}";
    }
}
