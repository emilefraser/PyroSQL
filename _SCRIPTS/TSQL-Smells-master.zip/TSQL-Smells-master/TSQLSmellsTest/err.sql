﻿Create view [dbo].[err]
	AS SELECT * FROM [TestTableSSDT]
