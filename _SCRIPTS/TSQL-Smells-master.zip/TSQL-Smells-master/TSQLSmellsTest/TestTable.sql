﻿CREATE TABLE [dbo].[TestTableSSDT]
(
	[IdCol] INT NOT NULL PRIMARY KEY,
	Col1 integer,
	Col2 integer,
	Col3 integer,
	DateCol datetime

)
