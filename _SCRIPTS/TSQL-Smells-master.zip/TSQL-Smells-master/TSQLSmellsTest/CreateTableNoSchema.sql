Create Table TestTableNoSchema
(
ID integer
)