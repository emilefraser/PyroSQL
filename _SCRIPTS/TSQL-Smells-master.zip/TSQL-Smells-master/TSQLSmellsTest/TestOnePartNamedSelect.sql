
CREATE PROCEDURE dbo.TestOnePartNamedSelect
AS
Set nocount on;

SELECT IdCol FROM TestTableSSDT;
