
CREATE PROCEDURE CreateProcedureNoSchema
AS
SET NOCOUNT ON;
select Col1 from [dbo].TestTableSSDT
RETURN 1
