Create PRocedure dbo.SelectAs
as
Set nocount on ;
Declare @X table
(
   Id integer
)

Select * from @x

