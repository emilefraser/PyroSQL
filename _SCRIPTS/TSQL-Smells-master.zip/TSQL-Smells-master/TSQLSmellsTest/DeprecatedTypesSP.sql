Create Procedure dbo.DepTypes
as
Set nocount on
Declare @DP1 text
Declare @DP2 ntext



