Create Table dbo.SomeText
(
ID integer primary key,
    [SomeText] TEXT NULL
)



