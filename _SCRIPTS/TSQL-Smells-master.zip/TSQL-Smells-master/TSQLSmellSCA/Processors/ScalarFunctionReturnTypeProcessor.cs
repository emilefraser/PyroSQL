﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace TSQLSmellSCA
{
    public class ScalarFunctionReturnTypeProcessor
    {
        public ScalarFunctionReturnTypeProcessor()
        {
        }

        public void ProcessScalarFunctionReturnType(ScalarFunctionReturnType ReturnType)
        {
        }
    }
}