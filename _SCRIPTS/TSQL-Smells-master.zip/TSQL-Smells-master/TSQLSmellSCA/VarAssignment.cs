﻿namespace TSQLSmellSCA
{
    public class VarAssignment
    {
        public string SrcName;
        public string VarName;
    }
}