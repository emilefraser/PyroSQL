USE AdventureWorks
GO

IF OBJECT_ID('dbo.hierarchy_init') IS NOT NULL
	DROP FUNCTION dbo.hierarchy_init
GO

CREATE FUNCTION dbo.hierarchy_init()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT 
        initialization_token
    FROM dbo.hierarchy_init_inner(@@SPID)
)
GO


IF OBJECT_ID('dbo.hierarchy_anchor') IS NOT NULL
	DROP FUNCTION dbo.hierarchy_anchor
GO

CREATE FUNCTION dbo.hierarchy_anchor
(
	@initialization_token INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT TOP(1)
        *
    FROM dbo.hierarchy_anchor_inner(@@SPID, @initialization_token)
)
GO


IF OBJECT_ID('dbo.hierarchy_recursive') IS NOT NULL
	DROP FUNCTION dbo.hierarchy_recursive
GO

CREATE FUNCTION dbo.hierarchy_recursive
(
	@initialization_token INT
)
RETURNS TABLE
AS
RETURN
(
	SELECT
		*
	FROM dbo.hierarchy_recursive_inner(@initialization_token)
)
GO


IF OBJECT_ID('dbo.hierarchy_enqueue') IS NOT NULL
	DROP FUNCTION dbo.hierarchy_enqueue
GO

CREATE FUNCTION dbo.hierarchy_enqueue
(
	@id INT,
	@payload NVARCHAR(4000)
)
RETURNS TABLE
AS
RETURN
(
	SELECT
		0 AS value
	WHERE
		dbo.hierarchy_enqueue_inner(@id, @payload) IS NOT NULL
)
GO
