USE AdventureWorks
GO

SELECT
	x.*
FROM dbo.make_parallel()
CROSS APPLY
(
	SELECT 
		p.* 
	FROM dbo.hierarchy_init() AS hi
	CROSS APPLY 
	( 
		SELECT 
			i.EmployeeID, 
			i.FullPath 
		FROM 
		( 
			SELECT 
				ehw.EmployeeID, 
				CONVERT(VARCHAR(900), CONCAT('.', ehw.EmployeeID, '.')) AS FullPath 
			FROM dbo.hierarchy_anchor(hi.initialization_token) AS ha
			CROSS JOIN EmployeeHierarchyWide AS ehw
			WHERE 
				ehw.ManagerID IS NULL 

			UNION ALL 

			SELECT
				ehw.EmployeeID, 
				CONVERT(VARCHAR(900), CONCAT(hr.payload, ehw.EmployeeID, '.')) AS FullPath 
			FROM dbo.hierarchy_recursive(hi.initialization_token) AS hr 
			INNER JOIN EmployeeHierarchyWide AS ehw WITH (FORCESEEK) ON
				ehw.ManagerID = hr.id
		) AS i
		CROSS APPLY dbo.hierarchy_enqueue(i.EmployeeID, i.FullPath) AS he
	) AS p
) AS x
GO
